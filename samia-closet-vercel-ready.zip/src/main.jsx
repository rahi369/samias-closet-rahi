import React, {useEffect, useMemo, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {onAuthStateChanged, signInWithPopup, signOut} from 'firebase/auth';
import {collection, getDocs} from 'firebase/firestore';
import {auth, db, googleProvider} from './firebase';
import './styles.css';

const fallback=[
 {id:'w1',name:'Women Collection',category:'Women',price:450,description:'Add your products from the admin system.',stock:10},
 {id:'b1',name:'Boys / Men Collection',category:'Boys / Men',price:550,description:'Add your products from the admin system.',stock:10}
];

function App(){
 const [user,setUser]=useState(null),[products,setProducts]=useState(fallback),[cart,setCart]=useState(()=>{try{return JSON.parse(localStorage.getItem('sc_cart')||'[]')}catch{return[]}}),[menu,setMenu]=useState(false),[cat,setCat]=useState('All'),[search,setSearch]=useState(''),[loading,setLoading]=useState(true);
 useEffect(()=>onAuthStateChanged(auth,setUser),[]);
 useEffect(()=>{(async()=>{try{const snap=await getDocs(collection(db,'products'));const rows=snap.docs.map(d=>({id:d.id,...d.data()})).filter(p=>p.visible!==false);if(rows.length)setProducts(rows)}catch{}finally{setLoading(false)}})()},[]);
 useEffect(()=>localStorage.setItem('sc_cart',JSON.stringify(cart)),[cart]);
 const filtered=useMemo(()=>products.filter(p=>(cat==='All'||p.category===cat)&&(`${p.name} ${p.category} ${p.description||''}`.toLowerCase().includes(search.toLowerCase()))),[products,cat,search]);
 const count=cart.reduce((a,p)=>a+p.qty,0),subtotal=cart.reduce((a,p)=>a+p.price*p.qty,0);
 const add=p=>setCart(c=>{const i=c.findIndex(x=>x.id===p.id);if(i>=0){const n=[...c];n[i]={...n[i],qty:n[i].qty+1};return n}return [...c,{...p,qty:1}]});
 const login=async()=>{try{await signInWithPopup(auth,googleProvider)}catch(e){alert(e?.message||'Login failed')}};
 return <>
  <header className="header"><a href="#home" className="logo"><img src="/logo.jpg" alt="Samia's Closet"/><span>SAMIA’S CLOSET</span></a><button className="hamb" onClick={()=>setMenu(!menu)}>☰</button><nav className={menu?'open':''}><a href="#products" onClick={()=>setMenu(false)}>Products</a><a href="#rewards" onClick={()=>setMenu(false)}>Rewards</a><a href="#orders" onClick={()=>setMenu(false)}>📦 Orders</a><a href="#contact" onClick={()=>setMenu(false)}>Contact</a><a href="#bag" onClick={()=>setMenu(false)}>🛍 Bag ({count})</a></nav></header>
  <main>
   <section id="home" className="hero"><div className="hero-copy"><p className="eyebrow">WOMEN • BOYS / MEN</p><h1>Style, curated<br/><i>for every day.</i></h1><p>Discover thoughtfully selected clothing from SAMIA’S CLOSET.</p><a className="btn" href="#products">Shop collection</a></div><div className="hero-mark">SC</div></section>
   <section id="products" className="section"><div className="section-top"><div><p className="eyebrow">COLLECTION</p><h2>Shop the collection</h2></div><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search products"/></div><div className="chips">{['All','Women','Boys / Men'].map(x=><button className={cat===x?'active':''} onClick={()=>setCat(x)} key={x}>{x}</button>)}</div>{loading?<p>Loading products…</p>:<div className="grid">{filtered.map(p=><article className="card" key={p.id}><div className="product-img">{p.imageUrl?<img src={p.imageUrl} alt={p.name}/>:<span>{p.category}</span>}</div><p className="tag">{p.category}</p><h3>{p.name}</h3><strong>৳{p.price}</strong><p>{p.description}</p><button className="btn small" onClick={()=>add(p)}>ADD TO BAG</button></article>)}</div>}</section>
   <section id="rewards" className="section cream"><p className="eyebrow">REWARDS</p><h2>Shop. Play. Collect.</h2><div className="reward-grid"><div><h3>Daily Quiz</h3><p>Login to unlock your rewards wallet and quiz experience.</p>{user?<span className="pill">Signed in</span>:<button className="btn" onClick={login}>LOGIN WITH GOOGLE</button>}</div><div><h3>Mystery Box</h3><p>Weekly reward experiences will be connected to Firebase.</p></div><div><h3>Purchase Streak</h3><p>Track your purchase streak and eligible gifts.</p></div></div></section>
   <section id="bag" className="section"><p className="eyebrow">YOUR BAG</p><h2>Shopping bag</h2>{cart.length?<><div className="bag">{cart.map((p,i)=><div className="bag-row" key={`${p.id}-${i}`}><div><b>{p.name}</b><span>Qty {p.qty}</span></div><strong>৳{p.price*p.qty}</strong><button onClick={()=>setCart(c=>c.filter((_,j)=>j!==i))}>Remove</button></div>)}</div><div className="total"><span>Subtotal</span><b>৳{subtotal}</b></div><p className="note">Checkout will use the Firebase order flow after the checkout module is configured.</p></>:<p>Your bag is empty.</p>}</section>
   <section id="orders" className="section split"><div><p className="eyebrow">CUSTOMER ACCOUNT</p><h2>{user?'Welcome back':'Your account'}</h2><p>{user?user.email:'Sign in to keep your account session and access orders.'}</p>{user?<button className="btn" onClick={()=>signOut(auth)}>LOG OUT</button>:<button className="btn" onClick={login}>CONTINUE WITH GOOGLE</button>}</div><div><p className="eyebrow">OWNER</p><h2>Direct Contact with Rahi</h2><p>Owner: Md. Humaun Husen Rahi</p><a className="btn" href="https://wa.me/8801834012069" target="_blank" rel="noreferrer">WHATSAPP</a></div></section>
   <section id="contact" className="section contact"><p className="eyebrow">CONTACT</p><h2>Let’s talk.</h2><p>WhatsApp: 01834012069</p><div><a href="https://www.facebook.com/share/1DxQzbBqLc/" target="_blank" rel="noreferrer">Facebook</a><a href="https://www.instagram.com/shop.with.samia?stkn=MWVtem5jdzJoNnNpyMw==" target="_blank" rel="noreferrer">Instagram</a><a href="https://www.tiktok.com/@shop.with.samia?_r=1&_t=ZS-9A8d6CHf0a6" target="_blank" rel="noreferrer">TikTok</a></div></section>
  </main><footer>SAMIA’S CLOSET <span>•</span> Owner: Md. Humaun Husen Rahi</footer>
 </>
}

createRoot(document.getElementById('root')).render(<App/>);
