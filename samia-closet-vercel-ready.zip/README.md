# SAMIA’S CLOSET — Vercel-ready Firebase frontend

## Run
1. `npm install`
2. `npm run dev`
3. `npm run build`
4. Deploy the project root to Vercel. Vercel should use `npm run build` and `dist` automatically.

Firebase project is configured in `src/firebase.js` with the supplied web-app configuration.

## Important
This build is a verified frontend foundation. It does not claim the complete production e-commerce/rewards/admin system from the long specification until those modules are implemented and tested.
